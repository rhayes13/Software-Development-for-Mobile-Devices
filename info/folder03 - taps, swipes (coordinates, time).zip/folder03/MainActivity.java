package cosc426.program;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private GestureDetector gestureDetector;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TouchHandler temp = new TouchHandler();
        gestureDetector = new GestureDetector(this, temp);
    }

    public boolean onTouchEvent(MotionEvent event)
    {
        gestureDetector.onTouchEvent(event);

        return true;
    }

    private class TouchHandler extends GestureDetector.SimpleOnGestureListener
    {
        public boolean onSingleTapConfirmed(MotionEvent event)
        {
            float x = event.getX();
            float y = event.getY();

            TextView outputTextView = (TextView)findViewById(R.id.output);
            outputTextView.setBackgroundColor(Color.parseColor("#990000"));
            outputTextView.setText(x + "\n" + y);

            return true;
        }

        public boolean onDoubleTap(MotionEvent event)
        {
            float x = event.getX();
            float y = event.getY();
            long time = event.getEventTime();

            TextView outputTextView = (TextView)findViewById(R.id.output);
            outputTextView.setBackgroundColor(Color.parseColor("#009900"));
            outputTextView.setText(x + "\n" + y + "\n" + time);

            return true;
        }

        public boolean onFling(MotionEvent event1, MotionEvent event2, float velocityX, float velocityY)
        {
            float startX = event1.getX(), startY = event1.getY();
            float endX = event2.getX(), endY = event2.getY();
            long time = event2.getEventTime() - event1.getEventTime();

            TextView outputTextView = (TextView)findViewById(R.id.output);
            outputTextView.setBackgroundColor(Color.parseColor("#999900"));
            outputTextView.setText((int)startX + " " + (int)startY + "\n" +
                                   (int)endX + " " + (int)endY + "\n" +
                                   time);

            return true;
        }
    }
}