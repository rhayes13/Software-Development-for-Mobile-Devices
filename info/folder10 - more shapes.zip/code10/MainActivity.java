package cosc426.program;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.Timer;

public class MainActivity extends AppCompatActivity
{
    private Game game;
    private GameView gameView;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        game = new Game(100, 400, 50, 10);

        gameView = new GameView(this, game);
        setContentView(gameView);

        GameTimerTask task = new GameTimerTask(game, gameView);
        Timer timer = new Timer();
        timer.schedule(task, 2000, 20);
    }
}