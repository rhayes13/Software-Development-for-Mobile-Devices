package cosc426.program;

public class Game
{
    private int centerX;
    private int centerY;
    private int radius;
    private int delta;

    public Game(int centerX, int centerY, int radius, int delta)
    {
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
        this.delta = delta;
    }

    public void move()
    {
        centerX = centerX + delta;
    }

    public int getCenterX()
    {
        return centerX;
    }

    public int getCenterY()
    {
        return centerY;
    }

    public int getRadius()
    {
        return radius;
    }
}
