package cosc426.program;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity
{
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        GraphicsView graphicsView = new GraphicsView(this);

        setContentView(graphicsView);
    }
}