package cosc426.program;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.graphics.Canvas;

public class GraphicsView extends View
{
     public GraphicsView(Context context)
     {
         super(context);
     }

     public void onDraw(Canvas canvas)
     {
         Paint paint = new Paint();
         paint.setColor(Color.parseColor("#990000"));
         paint.setStyle(Paint.Style.FILL);

         canvas.drawCircle(400, 600, 200, paint);
     }
}
