package cosc426.program;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.graphics.Canvas;

public class GameView extends View
{
     private Game game;

     public GameView(Context context, Game game)
     {
         super(context);

         this.game = game;
     }

     public void onDraw(Canvas canvas)
     {
         Paint paint = new Paint();
         paint.setColor(Color.parseColor("#990000"));
         paint.setStyle(Paint.Style.FILL);

         canvas.drawCircle(game.getCenterX(), game.getCenterY(), game.getRadius(), paint);
     }
}
