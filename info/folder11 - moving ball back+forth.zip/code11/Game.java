package cosc426.program;

public class Game
{
    private int centerX;
    private int centerY;
    private int radius;
    private int delta;
    private int sign;

    public Game(int centerX, int centerY, int radius, int delta)
    {
        this.centerX = centerX;
        this.centerY = centerY;
        this.radius = radius;
        this.delta = delta;
        this.sign = 1;
    }

    public void move()
    {
        centerX = centerX + sign*delta;

        if (centerX > 1050)
           sign = -1;
        else if (centerX < 50)
           sign = 1;
    }

    public void setDelta(int delta)
    {
        this.delta = delta;
    }

    public int getCenterX()
    {
        return centerX;
    }

    public int getCenterY()
    {
        return centerY;
    }

    public int getRadius()
    {
        return radius;
    }
}
