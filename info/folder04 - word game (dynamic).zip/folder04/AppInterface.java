package cosc426.program;

import android.view.Gravity;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.content.Context;
import android.util.TypedValue;

public class AppInterface extends RelativeLayout
{
    private final int SIZE = 10;

    private TextView[] words;

    public AppInterface(Context context, int screenHeight)
    {
        super(context);

        words = new TextView[SIZE];

        for (int i = 0; i < SIZE; i++)
        {
            words[i] = new TextView(context);
            words[i].setId(TextView.generateViewId());
            words[i].setBackgroundColor(Color.parseColor("#009900"));
            words[i].setTextColor(Color.BLACK);
            words[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
            words[i].setGravity(Gravity.CENTER);

            RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(0, 0);
            if (i > 0) params.addRule(RelativeLayout.BELOW, words[i-1].getId());
            params.width = LayoutParams.MATCH_PARENT;
            params.height = screenHeight/10;
            params.topMargin = 1;
            words[i].setLayoutParams(params);
            addView(words[i]);
        }
    }

    public void showCurrent(String[] current)
    {
        for (int i = 0; i < SIZE; i++)
            words[i].setText(current[i]);
    }

    public void stop()
    {
        for (int i = 0; i < SIZE; i++)
            words[i].setBackgroundColor(Color.parseColor("#990000"));
    }
}
