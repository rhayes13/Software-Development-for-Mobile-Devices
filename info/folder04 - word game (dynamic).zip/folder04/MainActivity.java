package cosc426.program;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.graphics.Point;
import android.view.GestureDetector;
import android.view.MotionEvent;

public class MainActivity extends AppCompatActivity         
{
    private final int SIZE = 10;

    private Game game;
    private AppInterface appInterface;
    private GestureDetector gestureDetector;
    private boolean gameOver;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        game = new Game();

        appInterface = new AppInterface(this, screenHeight());
        setContentView(appInterface);
        appInterface.showCurrent(game.getCurrent());

        TouchHandler temp = new TouchHandler();
        gestureDetector = new GestureDetector(this, temp);

        gameOver = false;
    }

    public boolean onTouchEvent(MotionEvent event)
    {
        if (!gameOver) gestureDetector.onTouchEvent(event);

        return true;
    }

    private int screenHeight()
    {
        Point size = new Point();
        getWindowManager().getDefaultDisplay().getSize(size);

        int DP = (int)(getResources().getDisplayMetrics().density);

        return size.y - 80*DP;
    }

    private class TouchHandler extends GestureDetector.SimpleOnGestureListener
    {
        public boolean onFling(MotionEvent event1, MotionEvent event2, float velocityX, float velocityY)
        {
            int startIndex = getY(event1)/(screenHeight()/SIZE);

            int endIndex = getY(event2)/(screenHeight()/SIZE);

            game.exchange(startIndex, endIndex);

            appInterface.showCurrent(game.getCurrent());

            if (game.solved())
            {
                appInterface.stop();
                gameOver = true;
            }

            return true;
        }

        private int getY(MotionEvent event)
        {
            int DP = (int)(getResources().getDisplayMetrics().density);

            return (int)(event.getY() - 80*DP);
        }
    }
}

