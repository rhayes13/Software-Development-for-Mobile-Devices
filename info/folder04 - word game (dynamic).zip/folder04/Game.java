package cosc426.program;
import java.util.Random;

public class Game
{
    private final int TOTAL = 3;
    private final int SIZE = 10;

    private Random random;

    private String[][] solutions = {{"I", "wrote", "Java", "program", "", "", "", "", "", ""},
                                    {"Two", "plus", "two", "is", "four", "", "", "", "", ""},
                                    {"finding", "sentence", "with", "ten", "words", "is", "harder", "than", "you", "think"}};
    private String[][] problems;
    private String[] current;
    private String[] solution;

    public Game()
    {
        random = new Random();

        problems = new String[TOTAL][SIZE];
        mix(solutions, problems);

        int select = random.nextInt(TOTAL);

        current = new String[SIZE];
        solution = new String[SIZE];

        for (int i = 0; i < SIZE; i++)
        {
            current[i] = problems[select][i];
            solution[i] = solutions[select][i];
        }
    }

    public String[] getCurrent()
    {
        return current;
    }

    public boolean solved()
    {
        for (int i = 0; i < SIZE; i++)
            if (!current[i].equals(solution[i]))
               return false;

        return true;
    }

    public void exchange(int i, int j)
    {
        String temp = current[i];
        current[i] = current[j];
        current[j] = temp;
    }

    private void mix(String[][] solutions, String[][] problems)
    {
         for (int i = 0; i < TOTAL; i++)
             mix(solutions[i], problems[i]);
    }

    private void mix(String[] solution, String[] problem)
    {
        for (int i = 0; i < solution.length; i++)
            problem[i] = solution[i];

        for (int i = problem.length-1; i >= 0; i--)
        {
            int j = random.nextInt(i+1);
            String temp = problem[i];
            problem[i] = problem[j];
            problem[j] = temp;
        }
    }
}
