package cosc426.program;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private int downCount, upCount, moveCount;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView squareTextView = (TextView)findViewById(R.id.square);
        TouchHandler temp = new TouchHandler();
        squareTextView.setOnTouchListener(temp);

        downCount = upCount = moveCount = 0;
    }

    private class TouchHandler implements View.OnTouchListener
    {
        public boolean onTouch(View view, MotionEvent event)
        {
            int action = event.getAction();

            if (action == MotionEvent.ACTION_DOWN)
                downCount++;
            else if (action == MotionEvent.ACTION_UP)
                upCount++;
            else if (action == MotionEvent.ACTION_MOVE)
                moveCount++;

            updateScene();

            return true;
        }

        private void updateScene()
        {
            TextView downTextView = (TextView)findViewById(R.id.down);
            downTextView.setText(downCount+"");

            TextView upTextView = (TextView)findViewById(R.id.up);
            upTextView.setText(upCount+"");

            TextView moveTextView = (TextView)findViewById(R.id.move);
            moveTextView.setText(moveCount+"");
        }
    }
}