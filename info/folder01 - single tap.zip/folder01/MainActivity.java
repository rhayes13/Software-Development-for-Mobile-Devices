package cosc426.program;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private GestureDetector gestureDetector;

    private int singleCount;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TouchHandler temp = new TouchHandler();
        gestureDetector = new GestureDetector(this, temp);

        singleCount = 0;
    }

    public boolean onTouchEvent(MotionEvent event)
    {
        gestureDetector.onTouchEvent(event);

        return true;
    }

    private class TouchHandler extends GestureDetector.SimpleOnGestureListener
    {
        public boolean onSingleTapConfirmed(MotionEvent event)
        {
            singleCount = singleCount + 1;

            TextView singleTapTextView = (TextView)findViewById(R.id.singleTap);
            singleTapTextView.setText(singleCount+"");

            return true;
        }
    }
}