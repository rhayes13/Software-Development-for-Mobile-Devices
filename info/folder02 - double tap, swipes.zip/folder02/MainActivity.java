package cosc426.program;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private GestureDetector gestureDetector;

    private int singleCount;
    private int doubleCount;
    private int swipeCount;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TouchHandler temp = new TouchHandler();
        gestureDetector = new GestureDetector(this, temp);

        singleCount = doubleCount = swipeCount = 0;
    }

    public boolean onTouchEvent(MotionEvent event)
    {
        gestureDetector.onTouchEvent(event);

        return true;
    }

    private class TouchHandler extends GestureDetector.SimpleOnGestureListener
    {
        public boolean onSingleTapConfirmed(MotionEvent event)
        {
            singleCount = singleCount + 1;

            TextView singleTextView = (TextView)findViewById(R.id.singleTap);
            singleTextView.setText(singleCount+"");

            return true;
        }

        public boolean onDoubleTap(MotionEvent event)
        {
            doubleCount = doubleCount + 1;

            TextView doubleTextView = (TextView)findViewById(R.id.doubleTap);
            doubleTextView.setText(doubleCount+"");

            return true;
        }

        public boolean onFling(MotionEvent event1, MotionEvent event2, float velocityX, float velocityY)
        {
            swipeCount = swipeCount + 1;

            TextView swipeTextView = (TextView)findViewById(R.id.swipe);
            swipeTextView.setText(swipeCount+"");

            return true;
        }
    }
}