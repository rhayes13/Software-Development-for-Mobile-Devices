package cosc426.program;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    private int downCount;
    private int upCount;
    private int moveCount;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        downCount = upCount = moveCount = 0;
    }

    public boolean onTouchEvent(MotionEvent event)
    {
        int action = event.getAction();

        if (action == MotionEvent.ACTION_DOWN)
           downCount++;
        else if (action == MotionEvent.ACTION_UP)
           upCount++;
        else if (action == MotionEvent.ACTION_MOVE)
           moveCount++;

        updateScene();

        return true;
    }

    private void updateScene()
    {
        TextView downTextView = (TextView)findViewById(R.id.down);
        downTextView.setText(downCount+"");

        TextView upTextView = (TextView)findViewById(R.id.up);
        upTextView.setText(upCount+"");

        TextView moveTextView = (TextView)findViewById(R.id.move);
        moveTextView.setText(moveCount+"");
    }
}