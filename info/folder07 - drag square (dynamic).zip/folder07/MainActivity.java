package cosc426.program;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends AppCompatActivity
{
    TextView square;
    RelativeLayout.LayoutParams params;
    int leftMargin, topMargin, startX, startY, currentX, currentY;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        createScene();
    }

    private void createScene()
    {
        RelativeLayout scene = new RelativeLayout(this);

        square = new TextView(this);
        square.setBackgroundColor(Color.parseColor("#009900"));

        params = new RelativeLayout.LayoutParams(0, 0);
        params.width = 600;
        params.height = 600;
        params.topMargin = 40;
        params.leftMargin = 40;
        square.setLayoutParams(params);

        TouchHandler temp = new TouchHandler();
        square.setOnTouchListener(temp);

        scene.addView(square);
        setContentView(scene);
    }

    private class TouchHandler implements View.OnTouchListener
    {
        public boolean onTouch(View view, MotionEvent event)
        {
            int action = event.getAction();

            if (action == MotionEvent.ACTION_DOWN)
            {
                leftMargin = params.leftMargin;
                topMargin = params.topMargin;

                startX = (int) event.getRawX();
                startY = (int) event.getRawY();
            }
            else if (action == MotionEvent.ACTION_MOVE)
            {
                currentX = (int) event.getRawX();
                currentY = (int) event.getRawY();

                params.leftMargin = leftMargin + currentX - startX;
                params.topMargin = topMargin + currentY - startY;

                square.setLayoutParams(params);
            }

            return true;
        }
    }
}