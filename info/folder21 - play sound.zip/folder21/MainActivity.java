package cosc426.program;

import android.media.SoundPool;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity
{
    private SoundPool soundPool;
    private int soundId;

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SoundPool.Builder soundPoolBuilder = new SoundPool.Builder();
        soundPool = soundPoolBuilder.build();
        soundId = soundPool.load(this, R.raw.music, 1);

        //playing background sound, delay play until load is complete
        //try {Thread.sleep(1000);} catch(Exception e){}
        //soundPool.play(soundId, 1, 1, 1, -1, 1);
    }

    public void play(View view)
    {
         soundPool.play(soundId, 1, 1, 1, -1, 1);
    }

    public void pause(View view)
    {
         soundPool.pause(soundId);
    }

    public void resume(View view)
    {
         soundPool.resume(soundId);
    }
}